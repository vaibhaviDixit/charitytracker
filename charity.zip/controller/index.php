<?php 

session_start();

include('settings/constants.php');
include('settings/functions.php');
require('view/template/layout/header.php');
require('service/donationService.php');

$page="home";

if(isset($_GET['page'])){
	$page=$_GET['page'];
}

if($page=="home"){
	require('view/template/index.php');
}
elseif ($page=="donation") {
	require('view/template/donation.php');
}
elseif ($page=="list") {
	require('view/template/index.php');
}




require('view/template/layout/footer.php');

?>