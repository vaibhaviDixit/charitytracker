<?php


define("SITE_NAME", "Charity Tracker");
define("SITE_PATH", "http://localhost/charity/");
// define("SITE_PATH", "http://aloktc.in/");


?>