
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title><?php echo SITE_NAME; ?></title>

   <!-- favicon-->
  <link rel="shortcut icon" href="view/static/img/favicon.png" type="image/svg+xml">

  <!-- CSS -->
  <link href="<?php echo SITE_PATH;?>view/static/css/style.css" rel="stylesheet">
  <link href="<?php echo SITE_PATH;?>view/static/css/bootstrap.min.css" rel="stylesheet">

     <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



</head>

<body>




  <!-- ======= Header ======= -->
  
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <span class="navbar-brand mb-0 h1"><?php echo SITE_NAME; ?></span>
  </div>
</nav>

