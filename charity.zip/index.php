<?php 

require('controller/index.php');

?>