<?php 
require("model/Homemodel.php");

$Homemodel=new Homemodel();
$donations=$Homemodel->getAllDonations();

$last=$Homemodel->getLastReceiptId();
$rid=$last+1;
$name="";
$phone="";
$addr="";
$totalamt="";
$duedate="";
$ridstatus="";



if(isset($_GET['id']) && $_GET['id']>0){

	$id=$_GET['id'];
	$donation=$Homemodel->getDonationById($id);

	$rid=$donation['receiptnum'];
	$ridstatus="readonly";
	$name=$donation['name'];
	$phone=$donation['phone'];
	$addr=$donation['address'];
	$totalamt=$donation['totalamt'];
	$duedate=$donation['duedate'];

}


if(isset($_POST['donate'])){

	if(!isset($_GET['id'])){

		if($Homemodel->checkRid($_POST)){
			alertMsg("Receipt Id already exists!");
		}
		else{

			$result=$Homemodel->saveNewDonor($_POST);
			if($result>0){
				alertMsg("Donor Added!");
				redirect(SITE_PATH."?page=list");
			}

		}
	}
	else{
			$result=$Homemodel->updateDonor($id,$_POST);
			if($result==1){
				redirect(SITE_PATH."?page=list");
			}
			else{
				alertMsg("Failed to update");
			}
		
	}
	
}

if(isset($_POST['pay'])){

	$result=$Homemodel->makePayment($_POST);
			if($result>0){
				alertMsg("Payment Added!");
				redirect(SITE_PATH."?page=list");
			}

}

?>